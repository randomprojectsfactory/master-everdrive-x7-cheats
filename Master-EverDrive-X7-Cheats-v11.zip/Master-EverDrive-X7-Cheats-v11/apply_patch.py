#!/usr/bin/env python3
"""Apply the cheats-only IPS to an exact official OS, without changing the input.
Python 3 standard library only. Accepts SMSOS.BIN or SMSOS-v1.04.zip.
"""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
import zipfile

HERE = Path(__file__).resolve().parent

def sha(data):
    return hashlib.sha256(data).hexdigest()

def apply_ips(source, patch):
    if patch[:5] != b'PATCH':
        raise ValueError('Invalid IPS header')
    data = bytearray(source)
    pos = 5
    while True:
        if pos + 3 > len(patch):
            raise ValueError('Truncated IPS record')
        offset_bytes = patch[pos:pos + 3]
        pos += 3
        if offset_bytes == b'EOF':
            if pos != len(patch):
                raise ValueError('Unexpected bytes after IPS end')
            return bytes(data)
        offset = int.from_bytes(offset_bytes, 'big')
        if pos + 2 > len(patch):
            raise ValueError('Truncated IPS length')
        size = int.from_bytes(patch[pos:pos + 2], 'big')
        pos += 2
        if not size:
            if pos + 3 > len(patch):
                raise ValueError('Truncated IPS repeat')
            size = int.from_bytes(patch[pos:pos + 2], 'big')
            replacement = patch[pos + 2:pos + 3] * size
            pos += 3
        else:
            if pos + size > len(patch):
                raise ValueError('Truncated IPS data')
            replacement = patch[pos:pos + size]
            pos += size
        if not size or offset + size > len(data):
            raise ValueError('Patch exceeds the expected OS size')
        data[offset:offset + size] = replacement

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('original', type=Path, help='Official SMSOS.BIN or SMSOS-v1.04.zip')
    parser.add_argument('--output', type=Path, default=Path('Master-X7-Cheats-v11-ready'),
                        help='New output folder; an existing folder is never replaced')
    args = parser.parse_args()
    try:
        meta = json.loads((HERE / 'manifest.json').read_text())
        if zipfile.is_zipfile(args.original):
            with zipfile.ZipFile(args.original) as archive:
                matches = [i for i in archive.infolist() if i.filename == 'SMSSYS/SMSOS.BIN']
                if len(matches) != 1 or matches[0].file_size != meta['base_size']:
                    raise ValueError('Archive must contain the official 65536-byte SMSSYS/SMSOS.BIN')
                source = archive.read(matches[0])
        else:
            if args.original.stat().st_size != meta['base_size']:
                raise ValueError('Expected a 65536-byte official OS file')
            source = args.original.read_bytes()
        if sha(source) != meta['base_sha256']:
            raise ValueError('Wrong source: use the original, unmodified SMSOS v1.04')
        patch = (HERE / meta['patch_file']).read_bytes()
        editor = (HERE / 'SMSSYS/CHTEDIT.BIN').read_bytes()
        if sha(patch) != meta['patch_sha256'] or sha(editor) != meta['editor_sha256']:
            raise ValueError('Patch package is damaged or changed')
        result = apply_ips(source, patch)
        if sha(result) != meta['output_sha256']:
            raise ValueError('Patched OS failed its SHA-256 check')
        output = args.output.resolve()
        if output.exists():
            raise ValueError('Output already exists; choose a new folder with --output')
        if not output.parent.is_dir():
            raise ValueError('The parent of the output folder must already exist')
        with tempfile.TemporaryDirectory(prefix='.master-x7-cheats-', dir=output.parent) as temporary:
            staging = Path(temporary) / 'ready'
            (staging / 'SMSSYS/CHEATS').mkdir(parents=True)
            (staging / 'SMSSYS/SMSOS.BIN').write_bytes(result)
            (staging / 'SMSSYS/CHTEDIT.BIN').write_bytes(editor)
            if sha((staging / 'SMSSYS/SMSOS.BIN').read_bytes()) != meta['output_sha256']:
                raise ValueError('Output readback failed')
            shutil.copyfile(HERE / 'README.txt', staging / 'README.txt')
            if output.exists():
                raise ValueError('Output appeared during patching; no existing files replaced')
            staging.rename(output)
        print('Created:', output)
        print('The input file was left unchanged. See README.txt for installation.')
    except (OSError, ValueError, KeyError, zipfile.BadZipFile) as error:
        parser.exit(1, 'Patch not applied: ' + str(error) + '\n')

if __name__ == '__main__':
    main()
